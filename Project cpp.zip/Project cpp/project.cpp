#include <iostream>
#include<limits>
#include<conio.h>
#include <cmath>
#include <string.h>
#include <stdio.h>
#include <cstdlib>
#include<fstream>
using namespace std;

string DecToBin(int a){
string r;
while(a != 0){
    r =( a % 2 == 0 ? "0" :"1") + r;
    a/=2;
    }
    return r;
}
int BinToDec(long long a){
int r = 0, i = 0, reste;
char t;
    while(a != 0){
    reste = a%10;
    t=char( reste +48);
    a /= 10;
    if(t=='0' || t =='1'){
    r += reste*pow(2,i);
    i++;
    }
    else{
        cout<<"ce n'est pas un binaire"<<endl;
        break;
    }
}
return r;
}
char DecToHex(int a){
 int i=0,j;
 int hex[1000];
 while(a!=0){
    hex[i]= a%16;
    i++;
    a/= 16;
 }
 for ( j=i-1 ;j>=0;j--){
    if (hex[j]>9){
          cout<<(char)(hex[j] + 55);
            }
    else{
        cout<<hex[j];
    }
}
 return 0;
}
string DecToOct(int a){
int i=0 , j ,oct[1000];
    while(a!=0){
oct[i]= a % 8;
i++;
a/=8;
 }
 for (j= i-1;j>=0;j--){
    cout<<oct[j];
 }
}
int HexToDec(char a[20]){
    int i, j=0, dec = 0,len ,r;
    char hex[20];
    len = strlen(a);
    for (i=len-1;i>=0;i--){
       hex[i]=a[i];
       if ( hex[i] >='A' && hex[i]<='F'){
        r =((int)(hex[i]))-55;
       }
       else if (hex[i]<= '9' && hex[i]>='0'){
        r =((int)(hex[i]))-48;
       }
       else if(hex[i]>='a' && hex[i]<='f')
        {
            r=(int)(hex[i])-87;
        }
       else{
        cout<<"Ce n'est pas un Hexa "<<endl;
        break;
       }
       dec += r*pow(16,j);
       j++;
    }
    int c = dec;
   return c;
}
int OctToDec(char a[20]){
 int i, j=0, dec=0, len=strlen(a) , r ,t;
 char oct[20];
 for(i=len-1;i>=0;i--){
    oct[i]=a[i];
    if(oct[i]>='0' && oct[i]<='7'){
    r=((int)(oct[i]))-48;
    dec+= r*pow(8,j);
    j++;
    }
    else{
        cout<<"ce n'est pas un octal"<<endl;
        break;
    }
 }
int c = dec;
return c;
 }
char BinToHex(long long a){
    return DecToHex(BinToDec(a));
}
string HexToBin( char a[1000]){
 return DecToBin(HexToDec(a));
}
string BinToOct(long long a){
return DecToOct(BinToDec(a));
}
string OctToBin(char a[1000]){
return DecToBin(OctToDec(a));
}
string HexToOct(char a[1000]){
 return DecToOct(HexToDec(a));
}
char OctToHex(char a[1000]){
return DecToHex(OctToDec(a));
}
void remplir_tab(int* p,int* tab,int l,int c)
{
    int k=0;
    for(int i=0;i<l;i++)
    {
        for(int j=0;j<c;j++)
        {
            p[k]=tab[k];
            k++;
        }
    }
    k=0;
    for(int i=0;i<l;i++)
    {
        for(int j=0;j<c;j++)
        {
            cout<<tab[k]<<"\t";
            k++;
        }
        cout<<endl;
    }
}

void ajout_valeur(int& val1,int& val2,int& val3,int& val4,int i,int j,int k,int L,int x,int n)
{
    if( (i==(L*2)-2 && j==n/2) || (i==(L*2)&& j!=n/2) )//cas de U
    {
        val1=k+3;
        val2=k+2;
        val3=k+1;
        val4=k;
    }
    else if(x-1!=0 && i>=(L*2)+2)//cas de X
    {
        val1=k+3;
        val2=k+1;
        val3=k+2;
        val4=k;
    }
    else//cas de L
    {
        val1=k;
        val2=k+2;
        val3=k+1;
        val4=k+3;
    }
}

void carre_simple_pair(int *p,int n)
{
    int tab[n][n],i,j,k;
    int x=((n/2)-1)/2, L=x+1;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            tab[i][j]=0;
        }
    }
    i=0;
    j=n/2;
    ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,1,L,x,n);
    for(k=5;k<=n*n;k+=4)
    {
        i-=2;
        j+=2;
        if(i>=0 && j<n && tab[i][j]==0)//case ok
        {
             ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,k,L,x,n);
        }
        else if(i>=0 && j<n && tab[i][j]!=0)//case occupe
        {
            i+=4;
            j-=2;
            ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,k,L,x,n);
        }
        else if(i<0 && j<n)//debordement en haut
        {
            i=n-2;
            ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,k,L,x,n);
        }
        else if(i>=0 && j>=n)//debordement a droite
        {
            j=1;
            ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,k,L,x,n);
        }
        else
        {
            i+=4;
            j-=2;
            ajout_valeur(tab[i][j],tab[i+1][j],tab[i+1][j-1],tab[i][j-1],i,j,k,L,x,n);
        }
    }
    remplir_tab(p,(int*)tab,n,n);
}

void carremagic4k(int o){
cout<<"Carre magique pair d'odre"<<endl;
int i ;
int j ;
int k= 1;
int p[30][30];
    for(i=0;i<o;i++){
        for(j=0;j<o;j++){
        {
                p[i][j]=k;
                k++;
				}
        }
				}
    for(i=0;i<o;i++){
        for(j=0;j<o;j++){
        if((((i%4==0)||((i+1)%4==0))&&((j%4==0)||((j+1)%4==0)))||((!(i%4==0)&&!((i+1)%4==0))&&(!(j%4==0)&&!((j+1)%4==0)))){
                p[i][j]=(o*o +1)-p[i][j];
				}
				cout<<p[i][j]<<"\t";
        }
       cout<<endl<<endl;
				}
				}

void equation() {
    float a,b,c,a1,b1,c1,x,y,det,xy;
    cout<<"      resoudre un systeme d'equation a 2 inconnues"<<endl;
    cout<<"    ax + by = c "<<endl<<"   a'x + b'y = c' "<<endl;
    cout<<"   Entre succesivement a  b  c  a'  b'  c' "<<endl;
    cin>>a;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a;
        }

    cin>>b;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }

    cin>>c;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }

    cin>>a1;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a1;
        }

    cin>>b1;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b1;
        }

    cin>>c1;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c1;
        }

    det= -(a*b1 - a1*b);
    x= (b*c1-b1*c)/det;
    y= (c*a1-c1*a)/det;
    xy=c/(a+b);
    if( det==0 && c!=c1){
        cout<<"   Pas de solution"<<endl;
    }
    else if(det==0 && c==c1){
        cout<<"x=y"<<xy<<endl;
    }
    else{
        cout<<"   La solution de l'equation est:"<<endl;
        cout<<" x="<<x<<endl;
        cout<<"  y="<<y<<endl;
    }
}
void multiplication_matrice(){
     int i,j,k;
    int N,M,P;
    int mat[30][30],mat1[30][30],mat2[30][30];
    cout<<"Donner le nombre de lignes de la premiere matrice : "<<endl;
    cin>>N;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>N;
        }

    cout<<"Donner la dimension commune aux 2 matrices : "<<endl;
    cin>>M;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>M;
        }

    cout<<"Donner le nombre de colonnes de la deuxieme matrice : "<<endl;
    cin>>P;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>P;
        }



//Remplissage de la premiere matrice--------------------------------------------

    cout<<"Donner les elements de la premiere matrice :"<<endl;
    for (i=0;i<N;i++){
        for (j=0;j<M;j++){
        cout<<"ligne: "<<i+1<<" colonne: "<<j+1<<endl;
        cin>>mat1[i][j];
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>mat1[i][j];
        }

        }
    }


//Remplissage de la seconde matrice---------------------------------------------
    cout<<"Donner les elements de la seconde matrice :"<<endl;
    for (i=0;i<M;i++)
        {
            for (j=0;j<P;j++)
             {
                 cout<<"ligne: "<<i+1<<" colonne: "<<j+1<<endl;
                  cin>>mat2[i][j];
                       while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>mat2[i][j];
        }

            }
        }


//Initialisation de la matrice r�sultante---------------------------------------
    for (i=0;i<N;i++)
        {
            for (j=0;j<P;j++)
                {
                mat[i][j]=0;
            }
            }

//Calcul de la matrice r�sultante-----------------------------------------------
    for (i=0;i<N;i++)
        {
            for (j=0;j<P;j++)
        {
            for (k=0;k<M;k++){
                    mat[i][j]=mat1[i][k]*mat2[k][j]+mat[i][j];
                }
            }
            }


//Affichage de la matrice r�sultante--------------------------------------------
    cout<<"Produit matriciel :"<<endl;
    for (i=0;i<N;i++)
        {
            for (j=0;j<P;j++)
            {
            cout<<"ligne: "<<i+1<<" colonne: "<<j+1<<endl;
            cout<<mat[i][j]<<endl;
            }
            }
            getch();

}
int fact(int n){
    int P=1;
    if(n==0) P=1;
     for(int i=1;i<=n;i++){
        P*=i;
     }
     return P;
     }

int determinant(int matrix[30][30],int n){
    int det=0;
    int submatrix[30][30];
if (n == 2)
 return ((matrix[0][0] * matrix[1][1]) - (matrix[1][0] * matrix[0][1]));
 else{
for(int x=0;x<n;x++){
        int subi = 0;
for (int i = 1; i < n; i++){
        int subj = 0;
for (int j = 0; j < n; j++) {
if (j == x)
    continue;
submatrix[subi][subj] = matrix[i][j];
 subj++;
 }
 subi++;
 }
 det = det + (pow(-1, x) * matrix[0][x] * determinant( submatrix, n - 1 ));
 }
 }
 return det;
 }
void trans_det(){
    int i,j,k,l,N,M;
    k =0;
    l=0;
    int mat[30][30];
    cout<<"Nombre de ligne de votre matice"<<endl;
    cin>>N;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>N;
        }

    M=N;
    for (i=0;i<N;i++){
        for (j=0;j<M;j++){
        cout<<"ligne: "<<i+1<<" colonne: "<<j+1<<endl;
        cin>>mat[i][j];
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>mat[i][j];
        }

        }
    }
    cout<<"La matrice entre est:"<<endl;
    for (i=0;i<N;i++){
        for (j=0;j<M;j++){
        cout<<mat[i][j]<<"  ";
        }
        cout<<endl;
    }
    cout<<"La transposer est"<<endl;
    for (j=0;j<M;j++){
        for (i=0;i<N;i++){
        cout<<mat[i][j]<<"   ";
        }
        cout<<endl;
    }
    cout<<"le determinant de la matrice entre est det= ";
    cout<<determinant( mat,N)<<endl;
}
bool is_unique(string b)
{
    ifstream testcode;
    testcode.open("testcode.txt", ios::app);
    string line;
    while(getline(testcode,line))
    {
        if(line == b)
        {
            return false;
        }
        else
        {
            true;
        }
    }
}
//fonction qui permet de rentre les information sur un etudiants
void add_student()
{
    string nom,prenom,adresse,code;
    cout<<"entre les informations d'un etudiant";
    ofstream fichier;
    ofstream testcode;//un autre flux creer pour stocker les codes etudiants dans un fichier a part
    fichier.open("text.txt",ios::app);
    testcode.open("testcode.txt",ios::app);
    char k = '0';
    while (int (k) == 48)
    {

            fflush(stdin);
            cout<<endl<<"entre le nom de l'etudiant: ";
            getline(cin,nom);

            cout<<endl<<"entre le prenom de l'etudiant: ";
            getline(cin,prenom);


            cout<<endl<<"entre l'adresse de l'etudiant: ";
            getline(cin,adresse);

            cout<<endl<<"entre le code de l'etudiant: ";
            getline(cin,code);

            if(fichier && testcode)
            {
                /*fichier<<nom<<"\t"<<prenom<<"\t"<<adresse<<"\t"<<code;
                fichier<<endl;*/

                if (is_unique(code))
                {
                    fichier<<nom<<"\t"<<prenom<<"\t"<<adresse<<"\t"<<code;
                    fichier<<endl;
                   testcode<<code;
                    testcode<<endl;
                }
                else
                {
                    cout<<"Some one else has this code"<<endl;
                }
            }
            else
            {
                cout<<"le fichier n'est pas creer";
                cout<<endl;
            }

        cout<<"appuyer sur 0 pour continuer: "<<endl;
        cin>>k;

    }

}
//fonction pour afficher et imprimer les informations des etudiants
void display_data()
{
    string line;
    char print;
    ifstream fichier;
    fichier.open("text.txt",ios::in);
    while(getline(fichier,line))
    {
        cout<<line<<endl;
    }
    cout<<"taper 1 pour imprimer le fichier"<<endl;
    cin>>print;
    if( int (print)==49)
    {
        string f = ("notepad.exe /p text.txt");
        system(f.c_str());
    }
}
void oderlist()
{
    int j=0;
    int i=0;
    string X;
    string line[20];
    ifstream fichier;
    fichier.open("text.txt",ios::in);
    while(getline(fichier,line[i])){
         if(int (line[i][0]) >97 && int (line[i][0])<122)
         {
            line[i][0]=char (int (line[i][0])-32);
         }
         i++;
    }
    for(int s=0;s<i;s++){
    for(j=1;j<i;j++){
    if(line[j]<line[j-1]){
        X =line[j];
        line[j]=line[j-1];
        line[j-1] = X;
    }
    }
    }
    for(int n=0;n<j;n++){
        cout<<line[n]<<endl;
    }
    }

void combin(){
int a;
cout<<"1) Factorielle"<<endl;
cout<<"2) Arrangement"<<endl;
cout<<"3)Combinaison"<<endl;
cin>>a;
     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a;
        }

while(a<1 || a>3){
    cout<<"Le numero choisir n'est pas dans la liste reessayer"<<endl;
    cin>>a;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a;
        }

}
switch (a){
case 1:{
     int n;
     cout<<"Entre le nombre"<<endl;
     cin>>n;
          while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

     while(n<0){
        cerr<<"impossible de calculer le factorielle d'un nombre negatif  Entre un nombre positif"<<endl;
        cin>>n;
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

     }
     fact(n);
     cout<<n<<"! est = "<<fact(n)<<endl;
     break;
}
case 2:{
    int n,p;
    float A;
    cout<<"Entre p"<<endl;
    cin>>p;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>p;
        }

    while(p<0){
        cout<<"p ne peut-etre negatif reessayer"<<endl;
        cin>>p;
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>p;
        }

    }
    cout<<"Entre n"<<endl;
    cin>>n;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

    while(n<p){
        cout<<"n ne peut etre inferieur a p reessayer"<<endl;
        cin>>n;
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

    }
    A=fact(n)/fact(n-p);
    cout<<"Arrangement de "<<p<<" dans "<<n<<" est = "<<A<<endl;
    break;
}
case 3:{
    int n,p;
    float C;
    cout<<"Entre p"<<endl;
    cin>>p;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>p;
        }

    while(p<0){
        cout<<"p ne peut-etre negatif reessayer"<<endl;
        cin>>p;
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>p;
        }

    }
    cout<<"Entre n"<<endl;
    cin>>n;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

    while(n<p){
        cout<<"n ne peut etre inferieur a p reessayer"<<endl;
        cin>>n;
             while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>n;
        }

    }
    C= fact(n)/(fact(n-p)*fact(p));
    cout<<" Combinaison de "<<p<<" dans "<<n<<" est = "<<C<<endl;
    break;
}
}

}

int main(){
    char a;
    int action;
    cout<<"----------------------------------------------------"<<endl;
    cout<<"----------------------------------------------------"<<endl;
    cout<< "__1) Codage Transcodage Decodage"<<endl<<"__2) Operations Mathematiques"<<endl<< "__3) Gestionaire de fichier "<<endl;
    cout<<"__4) Analyse Combinatoire"<<endl<<"__5)To exit"<<endl;
    cout<<"----------------------------------------------------"<<endl;
    do {
             cout<<"------------- CHOISIR UNE OPTION-------------------- "<<endl;
            cin>>a;
            action = int(a)-48;
    switch (action){
        case 1:{
        int a;
        cout<<"   Quelle est la base du nombre a convertir"<<endl;
        cout <<"   10 pour dec, 2 pour binaire, 16 pour Hex, 8 pour oct"<<endl;
        cin>>a;
        while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a;
        }
        while(a !=10 &&  a !=16 && a != 2 && a !=8){
            cout<<" Choisir une base de la liste proposer sinon tu vas recommencer"<<endl;
            cin>>a;
                  while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>a;
        }
        }
        switch (a){
        case 10:{
            int b;
            cout<<"  Dans quelle base vous voulez le convertir "<<endl;
            cin>>b;
            while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }
            while(b!= 16 && b!=8 && b!= 2){
                cout<<"choisir entre 16  2  ou 8 "<<endl;
                cin>>b;
                   while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }
            }
        switch(b){
        case 16:{
                int c;
                cout<<"  Entre le nombre"<<endl;
                cin>>c;
                  while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }
        while(c<0){
                cout<< "Ce programme a ete concues pour traiter les nombres entiers nons signes "<<endl;
                cin>>c;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }

            }
            DecToHex(c);
            cout<<endl;
            break;
                }
        case 2:{
                int c;
                cout<<"  Entrer le nombre"<<endl;
                cin>>c;
                  while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }
              while(c<0){
                cout<< "Ce programme a ete concues pour traiter les nombres positifs "<<endl;
                cin>>c;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }

            }
            cout<<DecToBin(c)<<endl;
            break;
            }
        case 8:{
                int c;
                cout<<"  Entrer le nombre"<<endl;
                cin>>c;
                  while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }
              while(c<0){
                cout<< "Ce programme a ete concues pour traiter les nombres positifs "<<endl;
                cin>>c;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>c;
        }

            }
            DecToOct(c);
            cout<<endl;
            break;
    }
                }
                break;
        }
        case 16:{
            int b;
            cout<<"Dans quelle base vous voulez le convertir "<<endl;
            cin>>b;
              while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }
            while(b!= 10 && b!=8 && b!= 2){
                cout<<"choisir entre 10  2  ou 8 "<<endl;
                cin>>b;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }

            }
            switch(b){
            case 10:{
            char c[20];
            int len = strlen(c);
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<HexToDec(c)<<endl;
            break;
            }
            case 2:{
            char c[20];
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<HexToBin(c)<<endl;
            break;
            }
            case 8:{
            char c[20];
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<HexToOct(c)<<endl;
            break;
            }
            }
            break;
        }
        case 2:{
            int b;
            cout<<"Dans quelle base vous voulez le convertir "<<endl;
            cin>>b;
              while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }
            while(b!= 10 && b!=8 && b!= 16){
                cout<<"choisir entre 10  16  ou 8 "<<endl;
                cin>>b;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }

            }
            switch(b){
            case 10:{
            long long c;
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<BinToDec(c)<<endl;
            break;
            }
            case 16:{
            long long c;
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<BinToHex(c)<<endl;
            break;
            }
              case 8:{
            long long c;
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<BinToOct(c)<<endl;
            break;
            }
            }
            break;
        }
        case 8:{
            int b;
            cout<<"Dans quelle base vous voulez le convertir "<<endl;
            cin>>b;
              while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }
            while(b!= 10 && b!=16 && b!= 2){
                cout<<"choisir entre 10  2  ou 16 "<<endl;
                cin>>b;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>b;
        }

            }
            switch(b){
            case 10:{
            char c[20];
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<OctToDec(c)<<endl;
            break;
            }
            case 16:{
            char c[20];
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<OctToHex(c)<<endl;
            break;
            }
              case 2:{
            char c[20];
            cout<<"entre le nombre"<<endl;
            cin>>c;
            cout<<OctToBin(c)<<endl;
            break;
            }
            }
            break;
        }
        }
        break;
        }
    case 2:{
        int k;
    cout<<"__1)Carre magique d'odre pair"<<endl;
    cout<<"__2) Multiplication de deux matrice"<<endl;
    cout<<"__3) Resolution d;une equation a deux inconnues"<<endl;
    cout<<"__4) Le determinant et la transposer d'un matrice"<<endl;
    cin>>k;
         while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>k;
        }

    switch (k){
        case 1:{
            int o;
            cout<<"Entre l'odre du carre"<<endl;
            cin>>o;
                 while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>o;
        }

            while(o%2!=0){
                cout<<"l'odre doit etre pair"<<endl;
                cin>>o;
                     while(cin.fail()){
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
            cout<<"Mauvaise entre, reesayer"<<endl;
        cin>>o;
        }

            }
            if(o%4 ==0){
        carremagic4k(o);
            }
            else{
                int p[o*o];
                carre_simple_pair(p,o);
            }
        break;

        }
        case 2:{
            multiplication_matrice();
            break;
        }
        case 3:{
            equation();
            break;
        }
        case 4:{
        trans_det();
        break;
        }
    }
    break;
    }
    case 3:{
    int a;
    cout<<"1) Ajouter les informations"<<endl;
    cout<<"2) affichage des informations avec possibilite d'impression"<<endl;
    cout<<"3) Afficher les etudiant en ordres alphabetiques en odre alphabetique"<<endl;
    cin>>a;
    while(a<1 || a>3){
        cout<< "le numero entre n'est pas dans la liste  reessayer"<<endl;
        cin>>a;
        }
        switch(a){
        case 1:{
        add_student();
        break;
        }
        case 2:{
        display_data();
        break;
        }
        case 3:{
            oderlist();
        break;
        }
        }
        break;
    }
    case 4:{
    combin();
    break;
    }
    }
    }while(action!=5);
    if(action = 5){
        cout<<"Merci d'avoir utiliser le programme appuyer sur n'importe touche pour fermer.";
    }
}
